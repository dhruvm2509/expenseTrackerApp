import java.util.Set;


public class InputValidation {
    /**
    * This function validate the amount before creating 
    *  the transaction. The constrains are 1) 0 < amount < 1000
    * 2) should be a valid number
    * @param  amount double
    * @throws IllegalArgumentException when the amount does not satisfy this constrains   
    */

    public static void Validate_amount(double amount){
        if ((amount <= 0 || amount >= 1000)){
            throw new IllegalArgumentException("The amount needs to be within 0 and 1000");
        }
    }
    /**
    * This function validate the String that 
    * will be the input by the user.
    * @param  String Category
    * @throws IllegalArgumentException when the Category is not within the choices   
    */

    public static void Validate_category(String Category){
        Set<String> Categories = Set.of("food", "travel", "bills", "entertainment", "other");
        String LowerCaseCategory = Category.toLowerCase();
        if(!Categories.contains(LowerCaseCategory)){
            throw new IllegalArgumentException("The Category needs to be selected within food, travel, bills, entertainments, and others.");
        }
        
    }
}
