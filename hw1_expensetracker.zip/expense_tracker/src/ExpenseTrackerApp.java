import javax.swing.table.DefaultTableModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * The ExpenseTrackerApp class allows users to add/remove daily transactions.
 */
public class ExpenseTrackerApp {

  public static void main(String[] args) {
    
    // Create MVC components
    DefaultTableModel tableModel = new DefaultTableModel();
    tableModel.addColumn("Serial");
    tableModel.addColumn("Amount");
    tableModel.addColumn("Category");
    tableModel.addColumn("Date");
    

    
    ExpenseTrackerView view = new ExpenseTrackerView(tableModel);

    // Initialize view
    view.setVisible(true);

    // Handle add transaction button clicks
    view.getAddTransactionBtn().addActionListener(e -> {
      
      // Get transaction data from view
      try{
        double amount = view.getAmountField(); 
        InputValidation.Validate_amount(amount); //Validate Amount
        String category = view.getCategoryField();
        InputValidation.Validate_category(category);  //Validate Category
        Transaction t = new Transaction(amount, category.toLowerCase());
        view.addTransaction(t);
      }
      catch (NumberFormatException d){  // Catch the exception of parsing not Double primitive
        JOptionPane.showMessageDialog(new JFrame(), "Invalid Amount", "Invalid Input", JOptionPane.ERROR_MESSAGE);
      }
      catch (Exception d){    // Catch every other exception that is thrown by Input Validation methods
        JOptionPane.showMessageDialog(new JFrame(), d.getMessage(), "Invalid Input", JOptionPane.ERROR_MESSAGE);
      }
      
    });

  }

}